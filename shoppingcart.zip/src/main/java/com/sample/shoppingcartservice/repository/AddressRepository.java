package com.sample.shoppingcartservice.repository;

import org.springframework.data.repository.CrudRepository;

import com.sample.shoppingcartservice.model.Address;

public interface AddressRepository extends CrudRepository<Address, Integer> {
}
