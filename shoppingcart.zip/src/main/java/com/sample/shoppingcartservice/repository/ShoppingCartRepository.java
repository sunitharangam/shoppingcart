package com.sample.shoppingcartservice.repository;

import org.springframework.data.repository.CrudRepository;

import com.sample.shoppingcartservice.model.ShoppingCart;

public interface ShoppingCartRepository extends CrudRepository<ShoppingCart, Integer> {
}
