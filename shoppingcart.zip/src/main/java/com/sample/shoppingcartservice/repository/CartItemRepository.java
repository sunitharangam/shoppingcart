package com.sample.shoppingcartservice.repository;

import org.springframework.data.repository.CrudRepository;

import com.sample.shoppingcartservice.model.CartItem;
import com.sample.shoppingcartservice.model.CartItemId;

public interface CartItemRepository extends CrudRepository<CartItem, CartItemId> {
}
