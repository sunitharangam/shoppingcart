package com.sample.shoppingcartservice.repository;

import org.springframework.data.repository.CrudRepository;

import com.sample.shoppingcartservice.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer> {
}
