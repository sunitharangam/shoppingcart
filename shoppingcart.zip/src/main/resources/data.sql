insert into address values ('1', 'Singapore', 'Singapore', 'Robinson Road', null, null, '123456', null);
insert into address values ('2', 'London', 'United Kingdom', 'Robinson Road', null, null, '123456', null);
insert into address values ('3', 'New York', 'United States', 'Robinson Road', null, null, '123456', null);
insert into address values ('4', 'Bangkok', 'Thailand', 'Robinson Road', null, null, '123456', null);

insert into contact values ('1', 'alex@gmail.com', '12345678','1');
insert into contact values ('2', 'john@gmail.com', '12345678','2');
insert into contact values ('3', 'alice@gmail.com', '12345678','3');
insert into contact values ('4', 'mike@gmail.com', '12345678','4');

insert into customer values ('1', 'Alex', '0', '1');
insert into customer values ('2', 'John', '0', '2');
insert into customer values ('3', 'Alice', '1', '3');
insert into customer values ('4', 'Mike', '0', '4');

insert into product values ('1', 'Nike Running Shoes', '80.00', 'RUNNING-SHOES');
insert into product values ('2', 'Addidas Running Shoes', '100.00', 'RUNNING-SHOES');
insert into product values ('3', 'Calton Tenis Racket 702', '200.00', 'TENIS-RACKET');
insert into product values ('4', 'Calton Tenis Racket 666', '190.00', 'TENIS-RACKET');
insert into product values ('5', 'Nike Soccer Ball ', '90.00', 'SOCCER-BALL');
